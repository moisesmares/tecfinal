package mx.unam.aragon.ico.te.musicamvc.repositorios;

import mx.unam.aragon.ico.te.musicamvc.modelos.Libro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LibroRepository extends JpaRepository<Libro, Integer> {

}
