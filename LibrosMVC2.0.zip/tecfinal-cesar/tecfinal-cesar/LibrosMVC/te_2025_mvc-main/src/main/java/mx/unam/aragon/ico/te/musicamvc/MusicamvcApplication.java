package mx.unam.aragon.ico.te.musicamvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicamvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicamvcApplication.class, args);
	}

}
